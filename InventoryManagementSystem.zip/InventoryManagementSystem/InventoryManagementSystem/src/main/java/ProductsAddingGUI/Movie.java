/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ProductsAddingGUI;

import com.mycompany.inventorymanagementsystem.Category;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import javax.swing.border.EmptyBorder;
import java.io.*;
import com.mycompany.GUI.DigitalProducts.DigitalMovie;
import com.mycompany.inventorymanagementsystem.Product;


public class Movie extends JFrame implements ActionListener{
    JFrame f = new JFrame("Product Managing");
    ImageIcon icon;

    ArrayList<Product >arr= new ArrayList<>();
    JTextField id,name,price,format,director,duration; 
    JButton add,clear;
    
    public Movie() {
        loadDataFromFile();
        f.setSize(720, 1000);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.setResizable(true);
        f.setLocationRelativeTo(null);
        f.getContentPane().setBackground(Color.decode("#9AC5D4"));

        icon = new ImageIcon("src\\images\\s.png");
        JLabel img = new JLabel(icon);

        JLabel l1 = new JLabel("Add Movies ");
        l1.setHorizontalAlignment(l1.CENTER);

        JPanel top = new JPanel();
        top.setPreferredSize(new Dimension(720,200));
        top.setBackground(Color.decode("#9AC5D4"));
        top.setLayout(new BorderLayout());
        top.add(img, BorderLayout.NORTH);
        top.add(l1, BorderLayout.SOUTH);
        
        
        JPanel center = new JPanel();
        center.setPreferredSize(new Dimension(720,720));
        center.setBackground(Color.decode("#9AC5D4"));
        center.setLayout(new BorderLayout());
        
        JPanel item = new JPanel();
        item.setPreferredSize(new Dimension(720, 720));
        item.setBackground(Color.decode("#9AC5D4"));
        item.setLayout(null);

        JLabel label = new JLabel("Id");
        label.setBounds(30, 10, 120, 30);
        id = new JTextField();
        id.setBounds(30, 40, 120, 30);

        JLabel label2 = new JLabel("Name");
        label2.setBounds(30, 90, 120, 30); // Fixed the typo in the variable name
        name = new JTextField();
        name.setBounds(30, 120, 120, 30); // Fixed the typo in the variable name

        JLabel label3 = new JLabel("Price");
        label3.setBounds(30, 170, 120, 30);
        price = new JTextField();
        price.setBounds(30, 200, 120, 30);

        JLabel label4 = new JLabel("Format");
        label4.setBounds(30, 250, 120, 30);
        format = new JTextField();
        format.setBounds(30, 280, 120, 30);

        JLabel label5 = new JLabel("Director");
        label5.setBounds(30, 330, 120, 30);
        director = new JTextField();
        director.setBounds(30, 360, 120, 30);

        JLabel label6 = new JLabel("Duration");
        label6.setBounds(30, 410, 120, 30);
        duration = new JTextField();
        duration.setBounds(30, 440, 120, 30);
        
        add= new JButton("Add");
        add.setIcon(new ImageIcon("src\\Images\\add.png"));
        add.addActionListener(this);
        add.setBounds(300, 360,120, 30);
        
        clear= new JButton("Clear");
        clear.addActionListener(this);
        clear.setIcon(new ImageIcon("src\\Images\\eraser.png"));
        clear.setBounds(300, 440,120, 30);
        
        
        item.add(add);
        item.add(clear);

        item.add(label);
        item.add(label2);
        item.add(label3);
        item.add(label4);
        item.add(label5);
        item.add(label6);

        item.add(id);
        item.add(name);
        item.add(price);
        item.add(format);
        item.add(director);
        item.add(duration);

        center.add(item, BorderLayout.NORTH);

        
        
        
       
        

        f.setLayout(new BorderLayout());
        f.add(top, BorderLayout.NORTH);
        f.add(center,BorderLayout.CENTER);
        
        
        f.setVisible(true);
    }
    
    
    
    
    private void loadDataFromFile() {
    try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("Products.ser"))) {
        arr = (ArrayList<Product>) in.readObject();
    } catch (FileNotFoundException e) {
        System.out.println("File not found. Creating a new ArrayList.");
        arr = new ArrayList<>();
    } catch (EOFException e) {
        System.out.println("End");
    } catch (ClassNotFoundException | IOException e) {
        e.printStackTrace();
    }
}

    

    
    private void updateDataToFile() {
    try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("Products.ser"))) {
        out.writeObject(arr);
    } catch (IOException e) {
        e.printStackTrace();
    }
}
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==add){
            if(id.getText().equals("") ||name.getText().equals("") ||price.getText().equals("") ||format.getText().equals("") ||director.getText().equals("") ||duration.getText().equals("")  )
                JOptionPane.showMessageDialog(null, "Please fill all the fields");
            else {
                boolean check=true;
                String i=id.getText();
                
                String n=name.getText();
                int p=-1;
                try {
                    // Attempt to parse the text as an integer
                    p = Integer.parseInt(price.getText());
                } catch (NumberFormatException ex) {
                    // Handle the case when parsing fails
                    check=false;
                    JOptionPane.showMessageDialog(null, "Price should be an integer");
                }
                
                String f=format.getText();
                        
                String d=director.getText();
                
                int dur=-1;
                try {
                    // Attempt to parse the text as an integer
                    dur = Integer.parseInt(duration.getText());
                } catch (NumberFormatException ex) {
                    // Handle the case when parsing fails
                    check=false;
                    JOptionPane.showMessageDialog(null, "Count should be an integer");
                }
                
                
                if(check==true){
                    DigitalMovie digitalMovie= new DigitalMovie(i,n,p,f,d,dur);
                    arr.add(digitalMovie);
                    id.setText("");
                    name.setText("");
                    price.setText("");
                    format.setText("");
                    director.setText("");
                    duration.setText("");
                }
                
                
                
                
                updateDataToFile();
            }
            
        }
        else if(e.getSource()==clear)
        {
                id.setText("");
                name.setText("");
                price.setText("");
                format.setText("");
                director.setText("");
                duration.setText("");
        }
    }
    
    
   
}
    

