
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.GUI.DigitalProducts;

import com.mycompany.inventorymanagementsystem.DigitalProduct;
import java.io.Serializable;

public class Games extends DigitalProduct implements Serializable {
    private static final long serialVersionUID = 4661633562961544696L;
     private String genre;

    public Games(String productId, String productName, double price,String format, String genre) {
        super(productId,productName,price,format);
        this.genre = genre;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }
}