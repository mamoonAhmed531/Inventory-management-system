
package com.mycompany.GUI;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.EmptyBorder;

public class AboutUs extends JFrame implements ActionListener {
    JFrame f = new JFrame("ABOUT US");
    ImageIcon icon;
    JButton back;

    public AboutUs() {
        f.setSize(1000, 600);
        f.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        f.setResizable(true);
        f.setLocationRelativeTo(null);
        f.getContentPane().setBackground(Color.decode("#9AC5D4"));

        icon = new ImageIcon("src\\images\\s.png");
        JLabel img = new JLabel(icon);

        JLabel l1 = new JLabel("About Us");
        l1.setHorizontalAlignment(l1.CENTER);

        JPanel top = new JPanel();
        top.setBackground(Color.decode("#9AC5D4"));
        top.setLayout(new BorderLayout());
        top.add(img, BorderLayout.NORTH);
        top.add(l1, BorderLayout.SOUTH);
        
        back= new JButton("Back");
        top.add(back,BorderLayout.CENTER);
        back.addActionListener( this);

        
        JPanel centerPanel= new JPanel();
        centerPanel.setBackground(Color.decode("#9AC5D4"));
        centerPanel.setLayout(new BorderLayout());
        
        JLabel para = new JLabel("<html><p style='text-align: justify'>"
                + "Welcome to <b>A Mart</b>, where innovation meets reliability. "
                + "At A Mart, we are more than just a company; we are a dynamic community of dedicated individuals "
                + "committed to reshaping the landscape of inventory management. Our modern and forward-thinking approach "
                + "is reflected in every aspect of our organization, from our cutting-edge technology solutions to our diverse "
                + "and collaborative team. Step into a world of efficiency and trust, where our commitment to innovation, integrity, "
                + "and teamwork is the driving force behind our success. Explore a seamless and organized experience with A Mart – "
                + "your trusted partner in navigating the future of inventory management.</p>"
                + "<p style='text-align: justify;'>"
                +"Your trust in A Mart fuels our passion to exceed expectations and deliver unparalleled solutions." 
                 +"Thank you for being an integral part of our journey; together, we will shape a future where seamless inventory management is the key to your success.</p>" 
                + "</html>");
        para.setHorizontalAlignment(JLabel.CENTER);
        para.setVerticalAlignment(JLabel.NORTH);     
//        Another way to add padding
        para.setBorder(new EmptyBorder(20, 40, 20, 40));
        
        centerPanel.add(para,BorderLayout.NORTH);
       
        
        
        
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(Color.WHITE);
        
        
        JLabel developedByLabel = new JLabel("Developed by Abdullah Khan(FA22-BSE-028), Hizqeel Mirza(SP22-BSE-019), Rizwan Akhtar(FA23-BSE-121)");
        developedByLabel.setForeground(Color.black);
        
        bottomPanel.add(developedByLabel);
       
        

        f.setLayout(new BorderLayout());
        f.add(top, BorderLayout.NORTH);
        f.add(centerPanel, BorderLayout.CENTER);
        f.add(bottomPanel,BorderLayout.SOUTH);
        
        f.setVisible(true);
    }
  
    @Override
    public void actionPerformed(ActionEvent e) {
       if(e.getSource()==back)
           f.dispose();
           new Welcome();
    }
    
    
}
