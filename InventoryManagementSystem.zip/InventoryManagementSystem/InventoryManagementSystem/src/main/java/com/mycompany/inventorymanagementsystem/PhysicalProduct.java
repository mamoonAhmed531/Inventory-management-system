
package com.mycompany.inventorymanagementsystem;

import java.io.Serializable;


public class PhysicalProduct extends Product implements Serializable,PricingStrategy,Cloneable{
    private String productId;
    private String productName;
    private double price;
    private int quantity;
    private String size; 

    public PhysicalProduct(){}
    
    public PhysicalProduct(String productId, String productName, double price, int quantityInStock, String size) {
        super(productId,productName);
        this.price = price;
        this.quantity = quantityInStock;
        this.size = size;
    }
    public PhysicalProduct(PhysicalProduct p) {
        super(p.Id,p.name);
        this.price =p.getPrice() ;
        this.quantity = p.getQuantity();
        this.size = p.getSize();
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getSize() {
        return size;
    }

    public void setSize(String size) {
        this.size = size;
    }
    
    
    
    @Override
    public  String toString(){
        
        return (super.toString()+"\nQuantity: "+quantity+"\nPrice: "+price);
    }

    @Override
    public double getTotal() {
        return (this.price*this.quantity);
    }
    
}
