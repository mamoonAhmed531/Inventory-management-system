
package com.mycompany.GUI;


import ProductsAddingGUI.*;
import com.mycompany.GUI.PhysicalProducts.Cosmetics;
import com.mycompany.inventorymanagementsystem.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.util.ArrayList;

import java.awt.event.*;

public class categories extends JFrame implements ActionListener {
    ArrayList<Category> arr = new ArrayList<>();
    JFrame f = new JFrame("Categories");
    final JTable table;
    JLabel names;
    JRadioButton b1,b2;
    JTextField n,searching;
    DefaultTableModel model;
    JButton add,clear,delete,update,search,save,refresh,AddProduct,back;
   
    
    public categories() {
        
        
        
        f.setSize(1000, 600);
        f.setResizable(false);
        f.getContentPane().setBackground(Color.decode("#9AC5D4"));
        f.setLocationRelativeTo(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //main panel covering full screen
        JPanel main = new JPanel();
        main.setLayout(new BorderLayout());
        main.setBackground(Color.decode("#9AC5D4"));
        main.setPreferredSize(new Dimension(1000, 600));

        //top label with icon
        JLabel top = new JLabel("List of Categories");
        top.setHorizontalAlignment(JLabel.CENTER);
        top.setIcon(new ImageIcon("src\\Images\\package.png"));
        top.setPreferredSize(new Dimension(1000, 50));
        
        
        main.add(top, BorderLayout.NORTH);
        
        

        //left side panel
        JPanel left = new JPanel();
        left.setPreferredSize(new Dimension(400, 600));
        left.setBackground(Color.decode("#9AC5D4"));
        left.setBorder(new TitledBorder("New Category"));
        main.add(left, BorderLayout.WEST);

        //Items panel
        JPanel items = new JPanel();
        items.setLayout(null);
        items.setPreferredSize(new Dimension(400, 500));
        items.setBackground(Color.decode("#9AC5D4"));
        left.add(items, BorderLayout.SOUTH);

        names = new JLabel("Name");
        names.setBounds(20, 30, 120, 30);

        n = new JTextField();
        n.setBounds(20, 60, 120, 30);
        
        b1 = new JRadioButton("Physical Products",true);
        b1.setBounds(20,120,150, 30);
        b1.setBackground(Color.decode("#9AC5D4"));
        
        b2 = new JRadioButton("Digital Products",false);
        b2.setBounds(200,120,150, 30);
        b2.setBackground(Color.decode("#9AC5D4"));
        
        

        

        add = new JButton("Add");
        add.setIcon(new ImageIcon("src\\Images\\add.png"));
        add.addActionListener(this);
        add.setBounds(20, 300, 120, 30);
        

        clear = new JButton("Clear");
        clear.setIcon(new ImageIcon("src\\Images\\eraser.png"));
        clear.setBounds(160, 300, 120, 30);
        clear.addActionListener(this);
        
        refresh=new JButton("Refresh");
        refresh.setBounds(20, 250, 120, 30);
        refresh.addActionListener(this);
        
        save = new JButton("Save");
        save.setBounds(160, 250, 120, 30);
        save.addActionListener(this);
        
        AddProduct = new JButton("Add Products to Categories");
        AddProduct.setBounds(80, 350, 190, 30);
        AddProduct.addActionListener(this);
        
        back= new JButton("Back");
        back.setBounds(120, 390, 100,30);
        back.addActionListener(this);
        
        

        items.add(names);
        items.add(b1);
        items.add(b2);
        items.add(n);
        items.add(add);
        items.add(clear);
        items.add(save);
        items.add(refresh);
        items.add(AddProduct);
        items.add(back);

        //Right Panel which would contain the buttons delete,update,search and table of producrs
        JPanel right = new JPanel();
        right.setPreferredSize(new Dimension(550, 600));
        right.setBackground(Color.decode("#9AC5D4"));
        right.setBorder(new TitledBorder("Catgories Table"));
        main.add(right, BorderLayout.EAST);

        //Right Items Panel which would contain buttons
        JPanel rightItems = new JPanel();
        rightItems.setLayout(null);
        rightItems.setPreferredSize(new Dimension(600, 500));
        rightItems.setBackground(Color.decode("#9AC5D4"));
        right.add(rightItems, BorderLayout.SOUTH);

        delete = new JButton("Delete");
        delete.setIcon(new ImageIcon("src\\Images\\delete.png"));
        delete.setBounds(60, 10, 130, 30);
        rightItems.add(delete);
        delete.addActionListener(this);

        update = new JButton("Update");
        update.setIcon(new ImageIcon("src\\Images\\browser.png"));
        update.setBounds(200, 10, 130, 30);
        update.addActionListener(this);
        rightItems.add(update);

        search = new JButton(new ImageIcon("src\\Images\\search.png"));
        search.setBounds(500, 10, 40, 30);
        search.addActionListener(this);
        rightItems.add(search);

        searching = new JTextField();
        searching.setBounds(340, 10, 200, 30);
        rightItems.add(searching);
        //items task ends here

        JPanel tablePanel = new JPanel();
        tablePanel.setBounds(0, 50, 600, 450);
        tablePanel.setBackground(Color.decode("#9AC5D4"));
        rightItems.add(tablePanel);

        String data[][] = {
            };

        String column[] = {"Id", "Name", "Code"};
        model = new DefaultTableModel(data, column);

        table = new JTable(model) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Make all cells non-editable
                return false;
            }
        };

        JScrollPane scrollPane = new JScrollPane(table);

        tablePanel.add(scrollPane);

        f.add(main);
       
        f.setVisible(true);
        
    }
    
    private void loadDataFromFile() {
        arr.clear();
        loadCategoriesFromFile("physicalProductsCategories.ser", "p");
        loadCategoriesFromFile("DigitalProductsCategories.ser", "d");
        
        
    }

    // Utility method to load categories from a file based on the code
    private void loadCategoriesFromFile(String fileName, String code) {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(fileName))) {
            while (true) {
                Category category = (Category) in.readObject();
                if (category == null) {
                    break;  // End of file reached
                }
                if (code.equals(category.getCode()) && !duplicate(category.getName())) {//Adding in a sequence p and then after that d
                    arr.add(category);
                    model.addRow(new Object[]{model.getRowCount() + 1, category.getName(), code});
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println(fileName + " not found!");
        } catch (EOFException e) {
            System.out.println("End reached!");
        } catch (ClassNotFoundException | IOException e) {
            e.printStackTrace();
        }
    }

    // Utility method to update data to files
    private void updateDataToFile() {
        updateCategoriesToFile("physicalProductsCategories.ser", "p");
        updateCategoriesToFile("DigitalProductsCategories.ser", "d");
    }

    // Utility method to update categories to a file based on the code
    private void updateCategoriesToFile(String fileName, String code) {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(fileName))) {
            for (Category c:arr) {
                String name = c.getName();
                String categoryCode = c.getCode();
                if (code.equals(categoryCode)) {//Adding in a sequence p and then after that d
                    out.writeObject(c);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }






    
    @Override
public void actionPerformed(ActionEvent a) {
    if (a.getSource() == add) {
        String name = n.getText(); // Use getText() for JTextField
        String code = b1.isSelected() ? "p" : "d";
        
        
        
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please fill all the fields!");
        }   
        else if(duplicate(name)){
            JOptionPane.showMessageDialog(null, "Duplicate alert");
        }
        else {
            arr.add(new Category(code,name));
            model.addRow(new Object[]{model.getRowCount() + 1, name, code});
            n.setText("");
        }
    } 
    
    
    //Code for delete Button
    else if (a.getSource() == delete) {
        int selectedRow = table.getSelectedRow();
        
        
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a row to delete!");
        } else {
            
            String name= (String)model.getValueAt(selectedRow, 1);
            String code= (String)model.getValueAt(selectedRow, 2);
            Category cat= new Category(code,name);
            int index=-1;
            for(Category c:arr){
                if(c.getName().equalsIgnoreCase(name) && c.getCode().equalsIgnoreCase(code))
                    index=arr.indexOf(c);
            }
            if(index>=0)
                arr.remove(index);
            model.removeRow(selectedRow);
            updateTableIndices();
        }
    }
    
    
    
    
    //Code for update button
    else if (a.getSource() == update) {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a row to update!");
        } else {
            String p=(String)model.getValueAt(selectedRow,1);
            String c=(String)model.getValueAt(selectedRow,2); 
            
            String name = n.getText(); // Use getText() for JTextField
            String code = b1.isSelected() ? "p" : "d";
            
            if (name.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill all the fields!");
            }
//            else if(duplicate(name))
//                JOptionPane.showMessageDialog(null, "Duplicate alert");
            else if(p.equals(name) && c.equals(code))
                JOptionPane.showMessageDialog(null, "Same values repeated");
//            else if(p.equals(name)){
//                int index = -1;
//                for(Category cat:arr){
//                    if(cat.getName().equalsIgnoreCase(name) && cat.getCode().equalsIgnoreCase(code))
//                        index=arr.indexOf(cat);
//                }
//                model.setValueAt(code, selectedRow, 2);
//                Category cat;
//                if(index!=-1){
//                    cat=arr.get(index);
//                    cat.setCode(code);
//                    arr.remove(index);
//                    arr.add(cat);
//                }
//                
//                    
//                
//                    
//            }   
//            else if(c.equals(code)){
//                int index=-1;
//                for(Category cat:arr){
//                    if(cat.getName().equalsIgnoreCase(name) && cat.getCode().equalsIgnoreCase(code))
//                        index=arr.indexOf(cat);
//                }
//                model.setValueAt(name, selectedRow, 1);
//                Category cat;
//                if(index!=-1){
//                    cat=arr.get(index);
//                    cat.setName(name);
//                    arr.remove(index);
//                    arr.add(cat);
//                }
//            }         
            else {
                int index=-1;
                for(Category cat:arr){
                    if(cat.getName().equalsIgnoreCase(p) && cat.getCode().equalsIgnoreCase(c))
                        index=arr.indexOf(cat);
                }
                model.setValueAt(name, selectedRow, 1);
                model.setValueAt(code, selectedRow, 2);
                Category cat;
                if(index!=-1){
                    cat=arr.get(index);
                    cat.setName(name);
                    cat.setCode(code);
                    arr.remove(index);
                    arr.add(cat);
                }
                n.setText("");
            }
        }
    }
    
    //Code for search button
    else if (a.getSource() == search) {
        String searchName = searching.getText();
        boolean found = false;

        for (int i = 0; i < model.getRowCount(); i++) {
            Object value = model.getValueAt(i, 1);
            String s=(String)value;
            if (value != null && s.equalsIgnoreCase(searchName)) {
                found = true;
                break;
            }
        }

        if (found) {
            JOptionPane.showMessageDialog(null, "Item found in the table!");
        } else {
            JOptionPane.showMessageDialog(null, "Item not found in the table!");
        }
    }
    else if(a.getSource()==clear){
        n.setText("");
        searching.setText("");
    }
    else if(a.getSource()==save)
        updateDataToFile();
        
    else if(a.getSource()==refresh){
        loadDataFromFile();
        print();
    }
        
    else if(a.getSource()==AddProduct)  {
        
        int s= table.getSelectedRow();
        if(s==-1){
            JOptionPane.showMessageDialog(null, "Please select a row!");
        }
        else{
            String catName=(String)model.getValueAt(s, 1);
            if(catName.equalsIgnoreCase("Clothing"))
                new Clothing();
            else if(catName.equalsIgnoreCase("Cosmetics"))
                new CosmeticsAdding();
            else if(catName.equalsIgnoreCase("Electronic"))
                new Electronic();
            else if(catName.equalsIgnoreCase("Furniture"))
                new Furniture();
            else if(catName.equalsIgnoreCase("Grocery"))
                new Grocery();
            else if(catName.equalsIgnoreCase("Movies"))
                new Movie();
            else if(catName.equalsIgnoreCase("Games"))
                new Game();
            else if(catName.equalsIgnoreCase("Softwares"))
                new Software();
            else if(catName.equalsIgnoreCase("Books"))
                new ProductAdding();
            else if(catName.equalsIgnoreCase("Music"))
                new Music();
        }
        
        
        
    } 
    else if(a.getSource()==back){
        f.dispose();
        new DashBoard();
    }
}

    //Utility function to check if entered data is already in the table or not
    private boolean duplicate(String name){
        for(int i=0;i<model.getRowCount();i++){
            for(int j=1;j<2;j++){
                String s=(String)model.getValueAt(i,j);
//                System.out.println(s);
                if(name.equals(s))
                   return true;
            
            }
        }
        return false;
    }
    private void updateTableIndices() {
        for (int i = 0; i < model.getRowCount(); i++) {
            model.setValueAt(i + 1, i, 0);
        }
    }
    
    private void print(){//Utility function code ky issues keliye :(
    for(Category c: arr){
        System.out.println(c);
        if(c.equals("Clothing"))
            for(Product p:c.getProducts()){
                System.out.println(p);
            }
        
    }
    
    
   
    }
    
   

    
}
