/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.GUI.PhysicalProducts;

/**
 *
 * @author malik
 */
import com.mycompany.inventorymanagementsystem.PhysicalProduct;
import java.io.Serializable;
public class Cosmetics extends PhysicalProduct implements Serializable{
    
    private static final long serialVersionUID = 4661633562961544696L;
    private String brand;
    private String type;

    public Cosmetics(String productId, String productName, double price, int quantityInStock,String size,String brand, String type) {
        super(productId, productName, price, quantityInStock,size);
        this.brand = brand;
        this.type = type;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    

    

}
