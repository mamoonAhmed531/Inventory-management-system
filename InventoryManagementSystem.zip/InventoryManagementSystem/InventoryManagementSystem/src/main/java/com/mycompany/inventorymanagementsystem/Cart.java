
package com.mycompany.inventorymanagementsystem;

import java.io.Serializable;
import java.util.ArrayList;

public class Cart implements Serializable{
    private ArrayList<Product> products;
    
    Cart(){
        products= new  ArrayList<>();
    }

    public ArrayList<Product> getProducts() {
        return products;
    }

    public void setProducts(ArrayList<Product> products) {
        this.products = products;
    }
    public void addItem(Product p){
        products.add(p);
    }
    
    public void removeItem(Product p){
        products.remove(p);
    }
    
    public double getTotalOfCart(){
        double total=0;
        for(Product p: products){
            if(p instanceof DigitalProduct){
                DigitalProduct pro= (DigitalProduct) p;
                total+=pro.getPrice();
            }
            else{
                DigitalProduct pro= (DigitalProduct) p;
                total+=pro.getPrice();
            }
            
        }
        
        return total;
    }
    
    
    
}
