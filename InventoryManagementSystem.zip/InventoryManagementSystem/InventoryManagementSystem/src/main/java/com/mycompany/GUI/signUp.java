
package com.mycompany.GUI;

import com.mycompany.inventorymanagementsystem.Admin;
import com.mycompany.inventorymanagementsystem.Customer;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.*;
import com.mycompany.inventorymanagementsystem.Inventory;
import java.util.ArrayList;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;


public class signUp extends JFrame implements ActionListener{
    ArrayList<Customer> customers= new ArrayList<>();
    JFrame f= new JFrame("Admin Login");
    ImageIcon admin;
    JButton signUp,back;
    JTextField age,firstName,lastName,userName;
    JPasswordField pass,confirmPass;
    public signUp(){
//        getCustomerCredentials();
        f.setSize(1000, 600);
        f.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        f.getContentPane().setBackground(Color.decode("#03445A"));
        f.setResizable(false);
        f.setLocationRelativeTo(null);
        
        
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BorderLayout());
        leftPanel.setBackground(Color.decode("#03445A"));
        
        admin = new ImageIcon("src\\images\\admin.png");
        JLabel imageLabel = new JLabel(admin);
        leftPanel.add(imageLabel, BorderLayout.CENTER);
        
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(null);
        rightPanel.setBackground(Color.decode("#03445A"));
        
        
        
        JLabel heading= new JLabel("Welcome to Signup");
        heading.setBounds(130, 50, 120, 30);
        heading.setForeground(Color.white);
        
        //For UserName;
        JLabel l1 = new JLabel("First Name:");
        l1.setBounds(50, 100, 100, 30);
        l1.setForeground(Color.white);
        firstName= new JTextField();
        firstName.setBounds(155, 105, 180, 20);
        
        
        //For Password
        JLabel l2 = new JLabel("Last Name:");
        l2.setBounds(50, 150, 100, 30);
        l2.setForeground(Color.white);
        lastName= new JTextField();
        lastName.setBounds(155, 155, 180, 20);
        
        JLabel l3 = new JLabel("Age:");
        l3.setBounds(50, 200, 100, 30);
        l3.setForeground(Color.white);
        age= new JTextField();
        age.setBounds(155, 205, 180, 20);
        
        JLabel l6 = new JLabel("UserName:");
        l6.setBounds(50, 250, 100, 30);
        l6.setForeground(Color.white);
        userName= new JTextField();
        userName.setBounds(155, 255, 180, 20);
        
        JLabel l4 = new JLabel("Password:");
        l4.setBounds(50, 300, 100, 30);
        l4.setForeground(Color.white);
        pass= new JPasswordField();
        pass.setBounds(155, 305, 180, 20);
        
        JLabel l5 = new JLabel("Confirm Pass:");
        l5.setBounds(50, 350, 100, 30);
        l5.setForeground(Color.white);
        confirmPass= new JPasswordField();
        confirmPass.setBounds(155, 355, 180, 20);
        
        
        signUp= new JButton("Signup");
        signUp.setBounds(130, 400, 105, 30);
        signUp.addActionListener(this);
        
        back= new JButton("Back");
        back.setBounds(130, 450, 105, 30);
        back.addActionListener(this);
        
        rightPanel.add(heading);
        rightPanel.add(l1);
        rightPanel.add(l2);
        rightPanel.add(l3);
        rightPanel.add(l4);
        rightPanel.add(l5);
        rightPanel.add(l6);
        
        rightPanel.add(firstName);
        rightPanel.add(lastName);
        rightPanel.add(age);
        rightPanel.add(confirmPass);
        rightPanel.add(pass);
        rightPanel.add(userName);
        
        
        rightPanel.add(signUp);
        rightPanel.add(back);
        
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(Color.WHITE);

        JLabel developedByLabel = new JLabel("Developed by Abdullah Khan(FA22-BSE-028), Hizqeel Mirza(SP22-BSE-019), Rizwan Akhtar(FA23-BSE-121)");
        developedByLabel.setForeground(Color.black);
        bottomPanel.add(developedByLabel);
        
        f.setLayout(new BorderLayout());
        f.add(leftPanel, BorderLayout.WEST);
        f.add(rightPanel, BorderLayout.CENTER);
        f.add(bottomPanel, BorderLayout.SOUTH);
        f.setVisible(true);
        
    }
    
    public void getCustomerCredentials() {
        try{
        ObjectInputStream input= new ObjectInputStream(new FileInputStream("customer.ser"));
            customers=(ArrayList<Customer>)input.readObject();
            input.close();
        }
        catch(EOFException a){
            System.out.println("End of File!");
        }
        catch(FileNotFoundException a){
            a.printStackTrace();
        }
        catch(IOException a){
            a.printStackTrace();
        }
        catch(ClassNotFoundException a){
            a.printStackTrace();
        }
        
        
    }
    
    private void updateDataToFile() {
    try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("customer.ser"))) {
        out.writeObject(customers);
    } catch (IOException e) {
        e.printStackTrace();
    }
}
   @Override
    public void actionPerformed(ActionEvent e) {

    if (e.getSource() == signUp) {
            char[] passwordChars = pass.getPassword();//character array to store password
            String password = new String(passwordChars);
            passwordChars=confirmPass.getPassword();//reusing same array to store confirmation password
            String confirm=new String(passwordChars);
            System.out.println(password);
            System.out.println(confirm);
        if(firstName.getText().equals("") || lastName.getText().equals("")|| age.getText().equals("") || userName.getText().equals("") ||password.equals("")|| confirmPass.equals(""))
            JOptionPane.showMessageDialog(null,"Please fill all the fields");
        else{
            
            boolean check=true;
            String message= "Invalid Password!"+"\nIt should be 8 charcter long"+"\nIt should contain a number"+"\nIt should contain a lowercase letter"+"\nIt shoukd contain an uppercase letter.";
            
            if(password.isEmpty() || (password.length()<8)){
                JOptionPane.showMessageDialog(null,message);
                check=false;
            }
                
            else if(!containsUppercaseLowercaseAndNumber(message)){
                JOptionPane.showMessageDialog(null,message);
                check=false;
            }
                
            else if(!password.equals(confirm)){
                check=false;
                JOptionPane.showMessageDialog(null,message); 
            }
            else {
                
                for (Customer a : customers) {
                    if (a.getUserName().equals(userName.getText())) {
                        check=false;
                        JOptionPane.showMessageDialog(null,"Customer account already exists");
                        
                }
            }
            
                String fName= firstName.getText();
                String lName=lastName.getText();
                String user=userName.getText();
                
                int a=-1;
                try{
                    a=Integer.parseInt(age.getText());
                    
                
                }catch(NumberFormatException exc){
                    check=false;
                    JOptionPane.showMessageDialog(null, "Age should be an integer!");
                }
                
                if(check==true){
                    Customer cus= new Customer(fName,lName,user,a,password);
                    customers.add(cus);
                    updateDataToFile();
                }
                    
            }
                
        
        
        }
    }
       
    
    else if(e.getSource()==back){
          f.dispose();
            new Welcome();
        }
    }

    
    private boolean containsUppercaseLowercaseAndNumber(String input) {
        boolean hasUppercase = false;
        boolean hasLowercase = false;
        boolean hasNumber=false;
        
        for (char character : input.toCharArray()) {
            if (Character.isUpperCase(character)) {
                hasUppercase = true;
            } else if (Character.isLowerCase(character)) {
                hasLowercase = true;
            } else if(Character.isDigit(character)){
                hasNumber=true;
            }

            
            if (hasUppercase && hasLowercase &&hasNumber) {
                break;
            }
        }

        return (hasUppercase && hasLowercase &&hasNumber);
    }
    
   
}
   
    

    

