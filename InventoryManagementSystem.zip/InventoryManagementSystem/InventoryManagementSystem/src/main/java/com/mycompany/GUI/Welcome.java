package com.mycompany.GUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import com.mycompany.inventorymanagementsystem.Inventory;

public class Welcome extends JFrame implements ActionListener{
    JFrame f = new JFrame("Welcome To A Mart");
    JButton admin, signUp, aboutUs;
    ImageIcon logo;
   
    public Welcome() {
     
        f.setSize(1000, 600);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().setBackground(Color.decode("#9AC5D4"));
        f.setResizable(false);
        f.setLocationRelativeTo(null);
        

        // Create left panel for image
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BorderLayout());
        leftPanel.setBackground(Color.BLACK);

        // Load the image from the resources folder
        logo = new ImageIcon("src\\images\\logo.png");
        JLabel imageLabel = new JLabel(logo);
        leftPanel.add(imageLabel, BorderLayout.CENTER);

        // Create right panel for menu label and buttons
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(null);
        rightPanel.setBackground(Color.decode("#9AC5D4"));

        JLabel label = new JLabel("MENU");
        label.setBounds(270, 120, 120, 30);
        label.setForeground(Color.white);

        admin = new JButton("Admin Login");
        admin.setBounds(230, 170, 150, 30);
        admin.addActionListener(this);

        signUp = new JButton("Customer Login");
        signUp.setBounds(230, 220, 150, 30);
        signUp.addActionListener(this);
        
        aboutUs = new JButton("About US");
        aboutUs.setBounds(230, 270, 150, 30);
        aboutUs.addActionListener(this);

        rightPanel.add(label);
        rightPanel.add(admin);
        rightPanel.add(signUp);
        rightPanel.add(aboutUs);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(Color.WHITE);

        JLabel developedByLabel = new JLabel("Developed by Abdullah Khan(FA22-BSE-028), Hizqeel Mirza(SP22-BSE-019), Rizwan Akhtar(FA23-BSE-121)");
        developedByLabel.setForeground(Color.black);
        bottomPanel.add(developedByLabel);

        // Add left, right, and bottom panels to the frame
        f.setLayout(new BorderLayout());
        f.add(leftPanel, BorderLayout.WEST);
        f.add(rightPanel, BorderLayout.CENTER);
        f.add(bottomPanel, BorderLayout.SOUTH);

        f.setVisible(true);
        
        
       
    }

    
    
     @Override
     public void actionPerformed(ActionEvent e) {
        if(e.getActionCommand().equals("Admin Login")){
              f.dispose();
              new login();
        } 
        else if(e.getSource()==signUp){
            f.dispose();
            new CustomerLogin();
        }
        else if(e.getActionCommand().equals("About US")){
            f.dispose();
            new AboutUs();
            
        }
             
    }
     
    

    
}

