
package com.mycompany.inventorymanagementsystem;


import java.io.*;
import java.util.ArrayList;
public class Category implements Serializable{
    protected ArrayList<Product> products;
    protected String code;
    private String name;
    
    public Category(){
        products = new ArrayList<>();
    }
    
    public Category(String code, String name){
    products = new ArrayList<>();
    this.code=code;
    this.name=name;
    }

    public ArrayList<Product> getProducts() {
        return products;
    }

    public void setProducts(ArrayList<Product> products) {
        this.products = products;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    
    
    public  void AddProduct(Product p){
        products.add(p);
        
    };
    public  void RemoveProduct(Product p){
    if(products.isEmpty())
            System.out.println("No products to delete");
    else{
        products.remove(p);
    }
    };
    public  void UpdateProduct(Product p,Product z){
        if(products.isEmpty())
            System.out.println("No products to update");
        else{
            int i= products.indexOf(p);
            products.set(i, z);
        }
    };
    
    
    
    
    
    @Override
    public String toString(){
        String s="Category Name: "+name+"\n";        
        for(Product p: products){
           s=s+p.toString()+"\n";
        }
        return s;
    }
    
    
    }
   
     
    

