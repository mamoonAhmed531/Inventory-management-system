
package com.mycompany.inventorymanagementsystem;


import java.util.ArrayList;
import java.io.*;

public class Inventory {
    private int id;
    private Admin admin;
    private ArrayList<Category> physicalProducts;
    private ArrayList<Category> DigitalProducts;
    
    public Inventory(){
        
        admin=null;
        physicalProducts= new ArrayList<>();
        DigitalProducts= new ArrayList<>();
        loadFile();
    }
    
    public Inventory(int id,Admin a){
        
        physicalProducts= new ArrayList<>();
        DigitalProducts= new ArrayList<>();
        loadFile();
        this.id=id;
        this.admin=a;
    }

    public void addCategory(Category c){
        if(c.code.equalsIgnoreCase("p")){
            physicalProducts.add(c);
            updatePhysicalCategoriesFile();
        }
           
        else
            DigitalProducts.add(c);
            updateDigitalCategoriesFile() ;   
    }
    
    public void removeCategory(Category c){
        if(c.code.equalsIgnoreCase("p")){
            if(physicalProducts.isEmpty())
                System.out.println("No Categories does not exist!");
            else if(physicalProducts.contains(c)){
                physicalProducts.remove(c);
                updatePhysicalCategoriesFile();
            }
                
            else
                System.out.println("Category does not exist!");
        }
            
        else{
            if(DigitalProducts.isEmpty())
                System.out.println("No Categories does not exist!");
            else if(DigitalProducts.contains(c)){
                DigitalProducts.remove(c);
                updateDigitalCategoriesFile();
            }
                
            else
                System.out.println("Category does not exist!");
        }
            
    }
    
    
        
        
 
    

    
   
    public void DisplayInventory(){
        System.out.println();
        for(Category c: physicalProducts){
            System.out.println(c.toString());
            
        }
        System.out.println();
        for(Category c: DigitalProducts){
            System.out.println(c.toString());
            
        }
    }
   
    
    
    
    
    
    private void updatePhysicalCategoriesFile() {
    ObjectOutputStream out = null;
    try {
        out = new ObjectOutputStream(new FileOutputStream("physicalProductsCategories.ser"));
        for(Category c: physicalProducts)
            out.writeObject(c);
        out.close();
    } catch (FileNotFoundException e) {
        System.out.println("Unable to find file!");
    } catch (IOException e) {
        e.printStackTrace();
    } 
}

private void updateDigitalCategoriesFile() {
    ObjectOutputStream out = null;
    try {
        out = new ObjectOutputStream(new FileOutputStream("DigitalProductsCategories.ser"));
        for(Category c: DigitalProducts)
            out.writeObject(c);
        out.close();
    } catch (FileNotFoundException e) {
        System.out.println("Unable to find file!");
    } catch (IOException e) {
        e.printStackTrace();
    }
}
    
    
    private void loadFile(){
        
        try{
            ObjectInputStream in= new ObjectInputStream(new FileInputStream("physicalProductsCategories.ser"));
            while(true){
                physicalProducts.add((Category)in.readObject());
            }
            
            
            
        }
        catch(FileNotFoundException e){
            System.out.println("Unable to find file!");
        }
        catch(EOFException e){
            System.out.println("End reached!");
        }
        catch(ClassNotFoundException e){
            e.printStackTrace();
        }
        catch(IOException e){
            e.printStackTrace();
        }
        
        try{
            ObjectInputStream inp= new ObjectInputStream(new FileInputStream("DigitalProductsCategories.ser"));
            while(true){
                DigitalProducts.add((Category)inp.readObject()); 
            }
                
        }
        catch(FileNotFoundException e){
            System.out.println("Unable to find file!");
        }
        catch(EOFException e){
            System.out.println("End reached!");
        }
        catch(ClassNotFoundException e){
            e.printStackTrace();
        }
        catch(IOException e){
            e.printStackTrace();
        }
        
        
    }



    
}
