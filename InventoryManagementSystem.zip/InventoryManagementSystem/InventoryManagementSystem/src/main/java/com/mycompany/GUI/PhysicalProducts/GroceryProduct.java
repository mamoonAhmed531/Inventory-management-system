/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.GUI.PhysicalProducts;

/**
 *
 * @author malik
 */
import com.mycompany.inventorymanagementsystem.PhysicalProduct;
import java.io.Serializable;
public class GroceryProduct extends PhysicalProduct implements Serializable{
    private String expirationDate;
    private String category;
    private static final long serialVersionUID = 4661633562961544696L;

    public GroceryProduct(String productId, String productName, double price, int quantityInStock,
                          String size,String expirationDate, String category) {
        super(productId, productName, price, quantityInStock,size);
        this.expirationDate = expirationDate;
        this.category = category;
    }

    public String getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    
}
