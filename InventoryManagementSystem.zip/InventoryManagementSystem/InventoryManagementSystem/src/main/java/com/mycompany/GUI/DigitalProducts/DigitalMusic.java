/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.GUI.DigitalProducts;

import com.mycompany.inventorymanagementsystem.DigitalProduct;
import java.io.Serializable;

/**
 *
 * @author malik
 */

public class DigitalMusic extends DigitalProduct implements Serializable{
    private static final long serialVersionUID = 4661633562961544696L;
    private String artist;
    private int duration;

    public DigitalMusic(String productId, String productName, double price,String format, String artist, int duration) {
        super(productId, productName, price,format);
        
        this.artist = artist;
        this.duration = duration;
    }
    
    

    // Additional methods specific to DigitalMusicProduct can be added here

    

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

}
