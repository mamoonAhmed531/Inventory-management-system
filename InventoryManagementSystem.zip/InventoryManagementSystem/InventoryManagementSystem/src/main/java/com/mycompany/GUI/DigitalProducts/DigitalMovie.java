/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.GUI.DigitalProducts;

import com.mycompany.inventorymanagementsystem.DigitalProduct;
import java.io.Serializable;

/**
 *
 * @author malik
 */
public class DigitalMovie extends DigitalProduct implements Serializable{
    
    private static final long serialVersionUID = 4661633562961544696L;
    private String director;
    private int duration;

    public DigitalMovie(String productId, String productName, double price,String format, String director, int duration) {
        super(productId, productName, price,format);
        
        this.director = director;
        this.duration = duration;
    }

   

    public String getDirector() {
        return director;
    }

    public void setDirector(String director) {
        this.director = director;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }
    
    
    
    

}
