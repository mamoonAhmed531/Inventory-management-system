
package com.mycompany.GUI;

import com.mycompany.inventorymanagementsystem.Customer;
import com.mycompany.inventorymanagementsystem.Inventory;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class CustomerDashboard extends JFrame implements ActionListener{
    JFrame f = new JFrame("Welcome To A Mart");
    JButton buy, checkout,back;
    ImageIcon logo;
    
   
    CustomerDashboard() {
        
        f.setSize(1000, 600);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().setBackground(Color.decode("#9AC5D4"));
        f.setResizable(false);
        f.setLocationRelativeTo(null);
        

        // Create left panel for image
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BorderLayout());
        leftPanel.setBackground(Color.BLACK);

        // Load the image from the resources folder
        logo = new ImageIcon("src\\images\\logo.png");
        JLabel imageLabel = new JLabel(logo);
        leftPanel.add(imageLabel, BorderLayout.CENTER);

        // Create right panel for menu label and buttons
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(null);
        rightPanel.setBackground(Color.decode("#9AC5D4"));

        JLabel label = new JLabel("MENU");
        label.setBounds(270, 120, 120, 40);
        label.setForeground(Color.white);

        buy = new JButton("Buy products");
        buy.setBounds(230, 170, 150, 40);
        buy.addActionListener(this);

        checkout = new JButton("Checkout");
        checkout.setBounds(230, 220, 150, 40);
        checkout.addActionListener(this);
        
        back = new JButton("Back");
        back.setBounds(230, 270, 150, 40);
        back.addActionListener(this);
        
        

        rightPanel.add(label);
        rightPanel.add(buy);
        rightPanel.add(checkout);
        rightPanel.add(back);
        

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(Color.WHITE);

        JLabel developedByLabel = new JLabel("Developed by Abdullah Khan(FA22-BSE-028), Hizqeel Mirza(SP22-BSE-019), Rizwan Akhtar(FA23-BSE-121)");
        developedByLabel.setForeground(Color.black);
        bottomPanel.add(developedByLabel);

        // Add left, right, and bottom panels to the frame
        f.setLayout(new BorderLayout());
        f.add(leftPanel, BorderLayout.WEST);
        f.add(rightPanel, BorderLayout.CENTER);
        f.add(bottomPanel, BorderLayout.SOUTH);

        f.setVisible(true);
        
        
       
    }
    
     @Override
     public void actionPerformed(ActionEvent e) {
        if(e.getSource()==buy){
            f.dispose();
            new buyProduct();
        }
        else if(e.getSource()==checkout){
            f.dispose();
//            new checkout();
        }
        else if(e.getSource()==back){
            f.dispose();
            new Welcome();
        }
             
    }
     
    
    
}



