
package com.mycompany.inventorymanagementsystem;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.*;


public class Admin implements Serializable {
    private String name;
    private String password;
    Inventory i;
    
    Admin(){
    }
    
    Admin(String s, String pass){
    name=s;
    password=pass;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Inventory getI() {
        return i;
    }

    public void setI(Inventory i) {
        this.i = i;
    }
    
    public static void main(String[] args) {
        Admin ad= new Admin("Abdullah","123");
        
        try{
        ObjectOutputStream output= new ObjectOutputStream(new FileOutputStream("admin.ser"));
            output.writeObject(ad);
            output.close();
        }
        catch(FileNotFoundException e){
            e.printStackTrace();
        }
        catch(IOException e){
            e.printStackTrace();
        }
    
    }
    
}
