

package com.mycompany.inventorymanagementsystem;

import com.mycompany.GUI.*;


public class InventoryManagementSystem {

    public static void main(String[] args) {
        new Welcome();
    }
}
