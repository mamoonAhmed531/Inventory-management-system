
package com.mycompany.inventorymanagementsystem;

import java.io.Serializable;


public abstract class Product implements Serializable{
    protected String Id;
    protected String name;
    
    public Product(){
    }
    
    public Product(String id, String name){
        this.Id=id;
        this.name=name;
        
    }

    public String getId() {
        return Id;
    }

    public void setId(String Id) {
        this.Id = Id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString(){
        return ("\nProduct Id: "+Id+"\nProduct Name: "+name);
    }
    
    
    
}
