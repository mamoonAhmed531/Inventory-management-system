/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.GUI.DigitalProducts;

import com.mycompany.inventorymanagementsystem.DigitalProduct;
import java.io.Serializable;

public class SoftwareProduct extends DigitalProduct implements Serializable{
    private static final long serialVersionUID = 4661633562961544696L;
    private String developer;
    private String version;

    public SoftwareProduct(String productId, String productName, double price,String format, String developer, String version) {
        super(productId, productName, price,format);
        this.developer = developer;
        this.version = version;
    }

    public String getDeveloper() {
        return developer;
    }

    public void setDeveloper(String developer) {
        this.developer = developer;
    }

    public String getVersion() {
        return version;
    }

    public void setVersion(String version) {
        this.version = version;
    }
}
