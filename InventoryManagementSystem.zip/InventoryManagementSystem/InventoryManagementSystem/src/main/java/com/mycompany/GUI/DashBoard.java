
package com.mycompany.GUI;

import com.mycompany.inventorymanagementsystem.Inventory;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class DashBoard extends JFrame implements ActionListener{
    JFrame f = new JFrame("Welcome To A Mart");
    JButton categories, products,back;
    ImageIcon logo;
   
    DashBoard() {
        
        f.setSize(1000, 600);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.getContentPane().setBackground(Color.decode("#9AC5D4"));
        f.setResizable(false);
        f.setLocationRelativeTo(null);
        

        // Create left panel for image
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BorderLayout());
        leftPanel.setBackground(Color.BLACK);

        // Load the image from the resources folder
        logo = new ImageIcon("src\\images\\logo.png");
        JLabel imageLabel = new JLabel(logo);
        leftPanel.add(imageLabel, BorderLayout.CENTER);

        // Create right panel for menu label and buttons
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(null);
        rightPanel.setBackground(Color.decode("#9AC5D4"));

        JLabel label = new JLabel("MENU");
        label.setBounds(270, 120, 120, 40);
        label.setForeground(Color.white);

        categories = new JButton("Manage Categories");
        categories.setBounds(230, 170, 150, 40);
        categories.addActionListener(this);

        products = new JButton("Manage Products");
        products.setBounds(230, 220, 150, 40);
        products.addActionListener(this);
        
        back = new JButton("Back");
        back.setBounds(230, 270, 150, 40);
        back.addActionListener(this);
        
        

        rightPanel.add(label);
        rightPanel.add(categories);
        rightPanel.add(products);
        rightPanel.add(back);
        

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(Color.WHITE);

        JLabel developedByLabel = new JLabel("Developed by Abdullah Khan(FA22-BSE-028), Hizqeel Mirza(SP22-BSE-019), Rizwan Akhtar(FA23-BSE-121)");
        developedByLabel.setForeground(Color.black);
        bottomPanel.add(developedByLabel);

        // Add left, right, and bottom panels to the frame
        f.setLayout(new BorderLayout());
        f.add(leftPanel, BorderLayout.WEST);
        f.add(rightPanel, BorderLayout.CENTER);
        f.add(bottomPanel, BorderLayout.SOUTH);

        f.setVisible(true);
        
        
       
    }
    
     @Override
     public void actionPerformed(ActionEvent e) {
        if(e.getSource()==categories){
            f.dispose();
            new categories();
        }
        else if(e.getSource()==products){
            f.dispose();
            new products();
        }
        else if(e.getSource()==back){
            f.dispose();
            new login();
        }
             
    }
     
   
    
}



