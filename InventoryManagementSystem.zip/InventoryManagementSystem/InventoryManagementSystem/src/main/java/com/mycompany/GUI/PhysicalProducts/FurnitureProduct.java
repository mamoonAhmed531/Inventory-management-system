/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.GUI.PhysicalProducts;

/**
 *
 * @author malik
 */
import com.mycompany.inventorymanagementsystem.PhysicalProduct;
import java.io.Serializable;
public class FurnitureProduct extends PhysicalProduct implements Serializable{
    
    private static final long serialVersionUID = 4661633562961544696L;
    private String material;
    private String dimensions;

    public FurnitureProduct(String productId, String productName, double price, int quantityInStock,
                            String size,String material, String dimensions) {
        super(productId, productName, price, quantityInStock,size);
        this.material = material;
        this.dimensions = dimensions;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getDimensions() {
        return dimensions;
    }

    public void setDimensions(String dimensions) {
        this.dimensions = dimensions;
    }

    

}
