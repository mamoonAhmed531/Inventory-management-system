
package com.mycompany.GUI;



import ProductsAddingGUI.*;
import com.mycompany.GUI.DigitalProducts.*;
import com.mycompany.GUI.PhysicalProducts.*;
import com.mycompany.inventorymanagementsystem.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.util.ArrayList;

import java.awt.event.*;
import java.util.Iterator;

public class buyProduct extends JFrame implements ActionListener {
    
    JFrame f= new JFrame("Inventory");
    JPanel items;
    DefaultTableModel model;
    JTable table;
    JComboBox box;
    JPanel tablePanel;
    ArrayList<Product> arr = new ArrayList<>();
    ArrayList<Category> cat = new ArrayList<>();
    ArrayList<Product> cart= new ArrayList<>();
    JTextField searching;
    JButton buy,show,search,refresh,back,checkout,cartManage,delete,backToMenu;
    
    
    public buyProduct(){
        loadCatFromFile();
        String [] cato= new String[10];
        
        
        f.setSize(1000, 600);
        f.setResizable(false);
        f.getContentPane().setBackground(Color.decode("#9AC5D4"));
        f.setLocationRelativeTo(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //main panel covering full screen
        JPanel main= new JPanel();
        main.setLayout(new BorderLayout());
        main.setBackground(Color.decode("#9AC5D4"));
        main.setPreferredSize(new Dimension(1000,600));
        
        //top label with icon
        JLabel top= new JLabel("List of Products");
        top.setHorizontalAlignment(JLabel.CENTER);
        top.setIcon(new ImageIcon("src\\Images\\package.png"));
        top.setPreferredSize(new Dimension(1000,50));
        main.add(top,BorderLayout.NORTH);
        
        //left side panel
        JPanel left= new JPanel();
        left.setPreferredSize(new Dimension(200,600));
        left.setBackground(Color.decode("#9AC5D4"));
        left.setBorder(new TitledBorder("Operations"));
        main.add(left,BorderLayout.WEST);
        
        //Items panel
        items= new JPanel();
        items.setLayout(null);
        items.setPreferredSize(new Dimension(150,500));
        items.setBackground(Color.decode("#9AC5D4"));
        left.add(items,BorderLayout.SOUTH);
        
    
        
        
    
        
        for(int i=0;i<cat.size();i++){
            cato[i]=cat.get(i).getName();
        }
        box= new JComboBox(cato);
        box.setBounds(10, 10,120, 30);
        
        
        
        buy= new JButton("Buy");
        buy.setBounds(10, 100,120, 30);
        buy.addActionListener(this);
        
        cartManage= new JButton("Manage Cart");
        cartManage.setBounds(10, 150,120, 30);
        cartManage.addActionListener(this);
        
        delete= new JButton("Delete");
        delete.setBounds(0, 0,0,0);
        delete.addActionListener(this);
        
        backToMenu= new JButton("Back");
        backToMenu.setBounds(0, 0,0,0);
        backToMenu.addActionListener(this);
        
        checkout= new JButton("Checkout");
        checkout.setBounds(10, 200,120, 30);
        checkout.addActionListener(this);
        
        show= new JButton("Show Changes");
        show.setBounds(10, 250,120, 30);
        show.addActionListener(this);
        
        
        
        back= new JButton("Back");
        back.setBounds(10, 300,120, 30);
        back.addActionListener(this);
        
        
        
        items.add(buy);
        items.add(checkout);
        items.add(box);
        items.add(show);
        items.add(back);
        items.add(cartManage);
        items.add(delete);
        items.add(backToMenu);
        
        tablePanel= new JPanel();
        tablePanel.setBounds(0, 50, 750, 450);
        tablePanel.setBackground(Color.decode("#9AC5D4"));
        
        
         String data[][] = {
            };

        String column[] = {};
        model = new DefaultTableModel(data, column);

        table = new JTable(model) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Make all cells non-editable
                return false;
            }
        };
        table.setPreferredScrollableViewportSize(new Dimension(700,450));
        JScrollPane scrollPane = new JScrollPane(table);

        tablePanel.add(scrollPane);
        
       
        
        
        //Right Panel which would contain the buttons delete,update,search and table of producrs
        JPanel right= new JPanel();
        right.setPreferredSize(new Dimension(750,600));
        right.setBackground(Color.decode("#9AC5D4"));
        right.setBorder(new TitledBorder("Products Table"));
        main.add(right,BorderLayout.EAST);
        
        //Right Items Panel which would contain buttons
        JPanel rightItems= new JPanel();
        rightItems.setLayout(null);
        rightItems.setPreferredSize(new Dimension(740,500));
        rightItems.setBackground(Color.decode("#9AC5D4"));
        right.add(rightItems,BorderLayout.SOUTH);
       
       
       
        
        search= new JButton(new ImageIcon("src\\Images\\search.png"));
        search.setBounds(500, 10,40,30);
        search.addActionListener(this);
        rightItems.add(search);
        
        searching= new JTextField();
        searching.setBounds(340, 10, 200, 30);
        rightItems.add(searching);
        //items task ends here
        rightItems.add(tablePanel);
        
       
      
      
      
      
     
      
      
       
                
        f.add(main);
        
        f.setVisible(true);
        
    }
    
    
    
    
    
    
    private void loadCatFromFile() {
        cat.clear();
        loadCategoriesFromFile("physicalProductsCategories.ser", "p");
        loadCategoriesFromFile("DigitalProductsCategories.ser", "d");
        
        
    }

    // Utility method to load categories from a file based on the code
    private void loadCategoriesFromFile(String fileName, String code) {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(fileName))) {
            while (true) {
                Category category = (Category) in.readObject();
                if (category == null) {
                    break;  // End of file reached
                }
                if (code.equals(category.getCode())) {
                    cat.add(category);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println(fileName + " not found!");
        } catch (EOFException e) {
            System.out.println("End reached!");
        } catch (ClassNotFoundException | IOException e) {
            e.printStackTrace();
        }
    }
    
   private void loadDataFromFile() {
    try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("Products.ser"))) {
        arr = (ArrayList<Product>) in.readObject();
    } catch (FileNotFoundException e) {
        System.out.println("File not found. Creating a new ArrayList.");
        arr = new ArrayList<>();
    } catch (EOFException e) {
        System.out.println("End");
    } catch (ClassNotFoundException | IOException e) {
        e.printStackTrace();
    }
}
   private void updateDataToFile() {
    try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("Products.ser"))) {
        out.writeObject(arr);
    } catch (IOException e) {
        e.printStackTrace();
    }
}





    
    @Override
public void actionPerformed(ActionEvent a) {
    
    if (a.getSource() == show) {
        loadDataFromFile();
        if (a.getSource() == show) {
            if (box.getSelectedItem().equals("Clothing")) {
                String data[][] = {};  // Initialize with actual data
                String column[] = {"Id", "Name", "Price", "Quantity", "Size", "Material", "Color"};
                model = new DefaultTableModel(data, column);
                table.setModel(model);
                Category cat;
                for(Product p:arr){
                    System.out.println(p);
                    if(p instanceof ClothingProducts){
                        System.out.println(p);
                        ClothingProducts cp=(ClothingProducts) p ;
                        model.addRow(new Object[]{p.getId(),p.getName(),cp.getPrice(),cp.getQuantity(),cp.getSize(),cp.getMaterial(),cp.getColor()});
                    }
                }
        }
           
  
        else if (box.getSelectedItem().equals("Cosmetics")) {
            String data[][] = {};  // Initialize with actual data
            String column[] = {"Id", "Name", "Price", "Quantity","Size", "Brand", "Type"};
            model = new DefaultTableModel(data, column);
            table.setModel(model);
            Category cat;
                for(Product p:arr){
                    if(p instanceof Cosmetics){
                        Cosmetics c=(Cosmetics) p ;
                        model.addRow(new Object[]{c.getId(),c.getName(),c.getPrice(),c.getPrice(),c.getSize(),c.getBrand(),c.getType()});
                    }
                }
            
            
            
        }
        
        
        
        else if (box.getSelectedItem().equals("Electronic")) {
            String data[][] = {};  // Initialize with actual data
            String column[] = {"Id", "Name", "Price", "Quantity","Size", "Material", "Color"};
            model = new DefaultTableModel(data, column);
            table.setModel(model);
            Category cat;
                for(Product p:arr){
                    if(p instanceof ElectronicProduct){
                        ElectronicProduct ep=(ElectronicProduct) p ;
                        model.addRow(new Object[]{ep.getId(),ep.getName(),ep.getPrice(),ep.getQuantity(),ep.getSize(),ep.getMaterial(),ep.getColor()});
                    }
                }   
        } 
        
        
        else if (box.getSelectedItem().equals("Furniture")) {
            String data[][] = {};  // Initialize with actual data
            String column[] = {"Id", "Name", "Price", "Quantity","Size" ,"Material", "Dimension"};
            model = new DefaultTableModel(data, column);
            table.setModel(model);
            Category cat;
                for(Product p:arr){
                    if(p instanceof FurnitureProduct){
                        FurnitureProduct fp=(FurnitureProduct) p ;
                        model.addRow(new Object[]{fp.getId(),fp.getName(),fp.getPrice(),fp.getQuantity(),fp.getSize(),fp.getMaterial(),fp.getDimensions()});
                    }
                }
        } 
        
        
        
        else if (box.getSelectedItem().equals("Grocery")) {
            
            String data[][] = {};  // Initialize with actual data
            String column[] = {"Id", "Name", "Price", "Quantity","Size","Expiry Date", "Type"};
            model = new DefaultTableModel(data, column);
            table.setModel(model);
            Category cat;
                for(Product p:arr){
                    if(p instanceof GroceryProduct){
                        GroceryProduct gp=(GroceryProduct) p ;
                        model.addRow(new Object[]{gp.getId(),gp.getName(),gp.getPrice(),gp.getQuantity(),gp.getSize(),gp.getExpirationDate(),gp.getCategory()});
                    }
                }
            
            
            
        } 
        
        
        
        else if (box.getSelectedItem().equals("Movies")) {
            String data[][] = {};  // Initialize with actual data
            String column[] = {"Id", "Name", "Price", "Format", "Director", "Duration(Minutes)"};
            model = new DefaultTableModel(data, column);
            table.setModel(model);
            Category cat;
                for(Product p:arr){
                    if(p instanceof DigitalMovie){
                        DigitalMovie dm=(DigitalMovie) p ;
                        model.addRow(new Object[]{dm.getId(),dm.getName(),dm.getPrice(),dm.getFormat(),dm.getDirector(),dm.getDuration()});
                    }
                }
            
            
            
        }
        
        
        
        else if (box.getSelectedItem().equals("Music")) {
            String data[][] = {};  // Initialize with actual data
            String column[] = {"Id", "Name", "Price", "Format", "Artist", "Duration(Minutes)"};
            model = new DefaultTableModel(data, column);
            table.setModel(model);
            for(Product p:arr){
                    if(p instanceof DigitalMusic){
                        DigitalMusic mus=(DigitalMusic) p ;
                        model.addRow(new Object[]{mus.getId(),mus.getName(),mus.getPrice(),mus.getFormat(),mus.getArtist(),mus.getDuration()});
                    }
                }
        } 
        
        
        
        else if (box.getSelectedItem().equals("Games")) {
            String data[][] = {};  // Initialize with actual data
            String column[] = {"Id", "Name", "Price", "Format", "Genre"};
            model = new DefaultTableModel(data, column);
            table.setModel(model);
            for(Product p:arr){
                    if(p instanceof Games){
                        Games g=(Games) p ;
                        model.addRow(new Object[]{g.getId(),g.getName(),g.getPrice(),g.getFormat(),g.getGenre()});
                    }
                }
        }
        
        
        
        
        else if (box.getSelectedItem().equals("Ebooks")) {
            String data[][] = {};  // Initialize with actual data
            String column[] = {"Id", "Name", "Price", "Format", "Author", "Pages Count"};
            model = new DefaultTableModel(data, column);
            table.setModel(model);
            for(Product p:arr){
                    if(p instanceof DigitalBook){
                        DigitalBook db=(DigitalBook) p ;
                        model.addRow(new Object[]{db.getId(),db.getName(),db.getPrice(),db.getFormat(),db.getAuthor(),db.getPageCount()});
                    }
                }
        } 
        
        
        
        
        else if (box.getSelectedItem().equals("Softwares")) {
            String data[][] = {};  // Initialize with actual data
            String column[] = {"Id", "Name", "Price", "Format", "Developer", "Version"};
            model = new DefaultTableModel(data, column);
            table.setModel(model);
            for(Product p:arr){
                    if(p instanceof SoftwareProduct){
                        SoftwareProduct sp=(SoftwareProduct) p ;
                        model.addRow(new Object[]{sp.getId(),sp.getName(),sp.getPrice(),sp.getFormat(),sp.getDeveloper(),sp.getVersion()});
                    }
                }
            
            
        }
    } 
        
  }
    
    else if(a.getSource()==buy)
    {
        int selectedRow=table.getSelectedRow();
        if(selectedRow==-1)
            JOptionPane.showMessageDialog(null,"Please select a product to buy");
        else {
            String id=(String) model.getValueAt(selectedRow,0);
            System.out.println(id);
            for(Product p:arr){
                if(p.getId().equals(id)){
                    boolean dpCheck=true;
                    if(p instanceof DigitalProduct){
                        for(Product p1:cart){
                           if(p1.getId().equals(p.getId()))//
                               dpCheck=false;
                        }
                        if(dpCheck==true)//if digital product is not in cart
                        {
                            cart.add(p);
                            JOptionPane.showMessageDialog(null,"Digital Product Added Succesfully to Cart");
                        } 
                        else    //if digital product is already in cart
                            JOptionPane.showMessageDialog(null, "Digital Product is already in the cart!");
                    }
                    else{
                        String userInput=JOptionPane.showInputDialog(null, "Enter the quantity");
                        int q=Integer.parseInt(userInput);
                        boolean check=true;
                        int quantity=0;
                        try{
                            quantity= (int) model.getValueAt(selectedRow,3);
                        }catch(NumberFormatException ex){
                            JOptionPane.showMessageDialog(null,"Out of stock");
                        }
                        
                      
                        PhysicalProduct pa=(PhysicalProduct) p ;
                        pa.setQuantity(quantity-q);
                        PhysicalProduct part= new PhysicalProduct((PhysicalProduct) p);
                        part.setQuantity(q);
                        
                        
                        if(q>quantity){
                            JOptionPane.showMessageDialog(null, "Sorry we dont have that much quantity!");
                            check=false;
                        }
                        
                        if(check==true){
                            boolean pCheck=true;
                            for(Product p1:cart){//if physcial product is already in Cart!
                                if(p1.getId().equals(p.getId())){
                                    PhysicalProduct p2=(PhysicalProduct)p1;
                                    p2.setQuantity(p2.getQuantity()+q);
                                    int s =pa.getQuantity();
                                    model.setValueAt(s, selectedRow, 3);
                                    pCheck=false;
                                    JOptionPane.showMessageDialog(null,"Physcial Product quantity updated in cart");
                                    updateDataToFile();
                                }
                                    
                             }
                             if(pCheck==true){//if physcial product not in Cart!
                                cart.add(part);
                                int s =pa.getQuantity();
                                model.setValueAt(s, selectedRow, 3);
                                JOptionPane.showMessageDialog(null,"New Product updated in cart");
                                updateDataToFile();
                            }
                            
                        }
                        
                    
                    
                    }
                    
                    
                }
            
            }
            
            
        }
    
    
    
    }
    

    
    else if(a.getSource()==search){
        String s=searching.getText();
        boolean found=false;
        for(int i=0;i<model.getRowCount();i++){
            for(int j=0;j<2;j++){
                if(model.getValueAt(i,j).equals(s)){
                    String sample= "Product Found\n1.Name: "+model.getValueAt(i,0)+"\n2.Id: "+model.getValueAt(i,1)+"\n3.Price"+model.getValueAt(i,2);
                    JOptionPane.showMessageDialog(null,sample);
                    found=true;
                    break;
                }
                
                    
            }
        }
        if(found==false)
            JOptionPane.showMessageDialog(null,"Cannot find product!");
        
    }
    else if(a.getSource() ==checkout){
        showCart();
        double total=0;
        if(cart.isEmpty()){
            JOptionPane.showMessageDialog(null,"No items in the cart");
        }
        else{
            for(Product p:cart){
                if(p instanceof DigitalProduct){
                    DigitalProduct pro= (DigitalProduct)p;
                    total+=pro.getTotal();
                }
                else{
                    PhysicalProduct pro= (PhysicalProduct)p;
                    System.out.println(pro.getQuantity());
                    total+=pro.getTotal();
                }
            }
         JOptionPane.showMessageDialog(null,"Payment Succesful\nTotal bill paid: "+total); 
         cart.clear();
        }
        
    
    
    }
    
    else if(a.getSource()==back){
        f.dispose();
        new CustomerDashboard();
    }    
    else if(a.getSource()==cartManage)
    {
        box.setBounds(0, 0,0, 0);
        buy.setBounds(0,0,0, 0);
        show.setBounds(0, 0,0, 0);
        checkout.setBounds(0, 0,0, 0);
        cartManage.setBounds(0, 0,0, 0);
        back.setBounds(0, 0, 0, 0);
        cartManage.setBounds(0, 0, 0, 0);
        search.setBounds(0, 0, 0, 0);
        
        delete.setBounds(10, 100,120, 30);
        backToMenu.setBounds(10, 150,120, 30);
        
        
        String row[][]={};
        String column[]={"Id","Name"};
        model= new DefaultTableModel(row,column);
        table.setModel(model);
        for(Product p: cart){
            model.addRow(new Object[]{p.getId(),p.getName()});
        }
        
    }
    else if (a.getSource() == delete) {
    int selectedRow = table.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(null, "Select a product in your cart to delete");
    } else {
        Iterator<Product> iterator = cart.iterator();
        while (iterator.hasNext()) {
            Product p = iterator.next();
            if (p instanceof DigitalProduct) {
                model.removeRow(selectedRow);
                iterator.remove(); 
                System.out.println("Deleted digital from cart");
                showCart();
            } else {
                PhysicalProduct p1 = (PhysicalProduct) p;
                for (Product p2 : arr) {
                    if (p2.getId().equals(p1.getId())) {
                        PhysicalProduct p3 = (PhysicalProduct) p2;
                        p3.setQuantity(p3.getQuantity() + p1.getQuantity());
                    }
                }
                iterator.remove(); // Safe removal using Iterator
                model.removeRow(selectedRow);
                System.out.println("Deleted physical from cart");
                showCart();
            }
        }
    }
}

    else if(a.getSource()==backToMenu){
        updateDataToFile();
        box.setBounds(10, 10,120, 30);
        buy.setBounds(10, 100,120, 30);
        cartManage.setBounds(10, 150,120, 30);
        checkout.setBounds(10, 200,120, 30);
        show.setBounds(10, 250,120, 30);
        back.setBounds(10, 300,120, 30);
        search.setBounds(500, 10,40,30);
        
        
        
        delete.setBounds(0, 0,0, 0);
        backToMenu.setBounds(0, 0,0, 0);
        
    
   
    }
}
   
    
    private void showCart(){
        for(Product p:cart){
            System.out.println(p.getName());
        }
    }
    public static void main(String[] args) {
        new buyProduct();
    }
    
}
