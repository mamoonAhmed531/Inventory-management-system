
package com.mycompany.inventorymanagementsystem;

import java.io.Serializable;


public class DigitalProduct extends Product implements Serializable,PricingStrategy{
    private static final int tax=20;
    private String productId;
    private String productName;
    private double price;
    private String format; 

    public DigitalProduct(String productId, String productName, double price, String format) {
        super(productId,productName);
        this.price = price;
        this.format = format;
    }
    
    

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }
    
    

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getFormat() {
        return format;
    }

    public void setFormat(String format) {
        this.format = format;
    }
    

    @Override
    public double getTotal() {
        double total=this.price+(this.price*(0.20));
        return total;
    }
}
    
    


