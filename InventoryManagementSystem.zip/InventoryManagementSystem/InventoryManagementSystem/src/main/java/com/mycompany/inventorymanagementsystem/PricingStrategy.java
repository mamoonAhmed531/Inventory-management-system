
package com.mycompany.inventorymanagementsystem;


public interface PricingStrategy {
    double getTotal();
}
