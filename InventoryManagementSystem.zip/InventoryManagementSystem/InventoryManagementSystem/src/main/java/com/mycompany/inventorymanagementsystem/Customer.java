
package com.mycompany.inventorymanagementsystem;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.*;
import java.util.ArrayList;

public class Customer implements Serializable {
    private String firstName;
    private String lastName;
    private int age;
    private String password;
    private String userName;
    private Cart c;
    
    Customer(){
        
    }
    
    

    public Customer(String fName, String lName,String user, int a, String password) {
        firstName=fName;
        lastName=lName;
        userName=user;
        age=a;
        this.password=password;
        c= new Cart();
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Cart getC() {
        return c;
    }

    public void setC(Cart c) {
        this.c = c;
    }

    
    
    

  
    
   
       
    
}
