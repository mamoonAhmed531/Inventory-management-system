/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.GUI.DigitalProducts;

import com.mycompany.inventorymanagementsystem.DigitalProduct;
import java.io.Serializable;

/**
 *
 * @author malik
 */
public class DigitalBook extends DigitalProduct implements Serializable{
   
    private static final long serialVersionUID = 4661633562961544696L;
    private String author;
    private int pageCount;

    public DigitalBook(String productId, String productName, double price,String format, String author, int pageCount) {
        super(productId, productName, price,format);
        this.author = author;
        this.pageCount = pageCount;
    }

   

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public int getPageCount() {
        return pageCount;
    }

    public void setPageCount(int pageCount) {
        this.pageCount = pageCount;
    }
    
    


}
