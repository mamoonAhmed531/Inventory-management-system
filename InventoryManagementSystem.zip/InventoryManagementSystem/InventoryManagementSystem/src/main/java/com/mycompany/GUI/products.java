
package com.mycompany.GUI;



import ProductsAddingGUI.*;
import com.mycompany.GUI.DigitalProducts.*;
import com.mycompany.GUI.PhysicalProducts.*;
import com.mycompany.inventorymanagementsystem.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.util.ArrayList;

import java.awt.event.*;
import java.util.Iterator;

public class products extends JFrame implements ActionListener {
    
    JFrame f= new JFrame("Inventory");
    JPanel items;
    DefaultTableModel model;
    JTable table;
    JComboBox box;
    JPanel tablePanel;
    ArrayList<Product> arr = new ArrayList<>();
    ArrayList<Category> cat = new ArrayList<>();
    JLabel label1,label2;
    JTextField quantity,price,searching;
    JButton clear,show,delete,update,search,refresh,save,back;
    
    
    public products(){
        loadCatFromFile();
        String [] cato= new String[10];
        
        
        f.setSize(1000, 600);
        f.setResizable(false);
        f.getContentPane().setBackground(Color.decode("#9AC5D4"));
        f.setLocationRelativeTo(null);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //main panel covering full screen
        JPanel main= new JPanel();
        main.setLayout(new BorderLayout());
        main.setBackground(Color.decode("#9AC5D4"));
        main.setPreferredSize(new Dimension(1000,600));
        
        //top label with icon
        JLabel top= new JLabel("List of Products");
        top.setHorizontalAlignment(JLabel.CENTER);
        top.setIcon(new ImageIcon("src\\Images\\package.png"));
        top.setPreferredSize(new Dimension(1000,50));
        main.add(top,BorderLayout.NORTH);
        
        //left side panel
        JPanel left= new JPanel();
        left.setPreferredSize(new Dimension(250,600));
        left.setBackground(Color.decode("#9AC5D4"));
        left.setBorder(new TitledBorder("Quantity"));
        main.add(left,BorderLayout.WEST);
        
        //Items panel
        items= new JPanel();
        items.setLayout(null);
        items.setPreferredSize(new Dimension(225,500));
        items.setBackground(Color.decode("#9AC5D4"));
        left.add(items,BorderLayout.SOUTH);
        
        label1= new JLabel("Quantity");
        quantity= new JTextField();
        
        
        
        label2= new JLabel("Price");
        label2.setBounds(10, 50, 100, 30);
        
        
        price= new JTextField();
        price.setBounds(100, 50, 120, 30);
        
        for(int i=0;i<cat.size();i++){
            cato[i]=cat.get(i).getName();
        }
        box= new JComboBox(cato);label1.setBounds(10, 10, 100, 30);
        quantity.setBounds(100, 10, 120, 30);
        box.setBounds(10,100,120, 30);
        
        clear= new JButton("Clear");
        clear.setIcon(new ImageIcon("src\\Images\\eraser.png"));
        clear.addActionListener(this);
        clear.setBounds(10, 150,100, 30);
        
        show= new JButton("Show Changes");
        show.setBounds(10, 200,120, 30);
        show.addActionListener(this);
        
        save= new JButton("Save Changes");
        save.setBounds(10, 250,120, 30);
        save.addActionListener(this);
        
        back= new JButton("Back");
        back.setBounds(10, 300,120, 30);
        back.addActionListener(this);
        
        
        
        items.add(label1);
        items.add(label2);
        items.add(price);
        items.add(quantity);
        items.add(clear);
        items.add(box);
        items.add(show);
        items.add(save);
        items.add(back);
       
        
        tablePanel= new JPanel();
        tablePanel.setBounds(0, 50, 700, 450);
        tablePanel.setBackground(Color.decode("#9AC5D4"));
        
        
         String data[][] = {
            };

        String column[] = {};
        model = new DefaultTableModel(data, column);

        table = new JTable(model) {
            @Override
            public boolean isCellEditable(int row, int column) {
                // Make all cells non-editable
                return false;
            }
        };

        JScrollPane scrollPane = new JScrollPane(table);
        table.setPreferredScrollableViewportSize(new Dimension(650,450));
        tablePanel.add(scrollPane);
        
       
        
        
        //Right Panel which would contain the buttons delete,update,search and table of producrs
        JPanel right= new JPanel();
        right.setPreferredSize(new Dimension(700,600));
        right.setBackground(Color.decode("#9AC5D4"));
        right.setBorder(new TitledBorder("Products Table"));
        main.add(right,BorderLayout.EAST);
        
        //Right Items Panel which would contain buttons
        JPanel rightItems= new JPanel();
        rightItems.setLayout(null);
        rightItems.setPreferredSize(new Dimension(670,500));
        rightItems.setBackground(Color.decode("#9AC5D4"));
        right.add(rightItems,BorderLayout.SOUTH);
        
        delete= new JButton("Delete");
        delete.setIcon(new ImageIcon("src\\Images\\delete.png"));
        delete.setBounds(60, 10,130,30);
        delete.addActionListener(this);
        rightItems.add(delete);
       
        update= new JButton("Update");
        update.setIcon(new ImageIcon("src\\Images\\browser.png"));
        update.setBounds(200, 10,130,30);
        update.addActionListener(this);
        rightItems.add(update);
        
        search= new JButton(new ImageIcon("src\\Images\\search.png"));
        search.setBounds(500, 10,40,30);
        search.addActionListener(this);
        rightItems.add(search);
        
        searching= new JTextField();
        searching.setBounds(340, 10, 200, 30);
        rightItems.add(searching);
        //items task ends here
        rightItems.add(tablePanel);
        
       
      
      
      
      
     
      
      
       
                
        f.add(main);
        
        f.setVisible(true);
        
    }
    
    
    
    
    
    
    private void loadCatFromFile() {
        cat.clear();
        loadCategoriesFromFile("physicalProductsCategories.ser", "p");
        loadCategoriesFromFile("DigitalProductsCategories.ser", "d");
        
        
    }

    // Utility method to load categories from a file based on the code
    private void loadCategoriesFromFile(String fileName, String code) {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(fileName))) {
            while (true) {
                Category category = (Category) in.readObject();
                if (category == null) {
                    break;  // End of file reached
                }
                if (code.equals(category.getCode())) {
                    cat.add(category);
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println(fileName + " not found!");
        } catch (EOFException e) {
            System.out.println("End reached!");
        } catch (ClassNotFoundException | IOException e) {
            e.printStackTrace();
        }
    }
    
   private void loadDataFromFile() {
    try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("Products.ser"))) {
        arr = (ArrayList<Product>) in.readObject();
    } catch (FileNotFoundException e) {
        System.out.println("File not found. Creating a new ArrayList.");
        arr = new ArrayList<>();
    } catch (EOFException e) {
        System.out.println("End");
    } catch (ClassNotFoundException | IOException e) {
        e.printStackTrace();
    }
}

    

    
    private void updateDataToFile() {
    try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("Products.ser"))) {
        out.writeObject(arr);
    } catch (IOException e) {
        e.printStackTrace();
    }
}

    

  
    






    
    @Override
public void actionPerformed(ActionEvent a) {
    if (a.getSource() == show) {
        loadDataFromFile();
        
            if (box.getSelectedItem().equals("Clothing")) {
                label1.setBounds(10, 10, 100, 30);
                quantity.setBounds(100, 10, 120, 30);
                String data[][] = {};  // Initialize with actual data
                String column[] = {"Id", "Name", "Price", "Quantity", "Size", "Material", "Color"};
                model = new DefaultTableModel(data, column);
                table.setModel(model);
                Category cat;
                for(Product p:arr){
                    System.out.println(p);
                    if(p instanceof ClothingProducts){
                        System.out.println(p);
                        ClothingProducts cp=(ClothingProducts) p ;
                        model.addRow(new Object[]{p.getId(),p.getName(),cp.getPrice(),cp.getQuantity(),cp.getSize(),cp.getMaterial(),cp.getColor()});
                    }
                }
        }
           
  
        else if (box.getSelectedItem().equals("Cosmetics")) {
            label1.setBounds(10, 10, 100, 30);
            quantity.setBounds(100, 10, 120, 30);
            String data[][] = {};  // Initialize with actual data
            String column[] = {"Id", "Name", "Price", "Quantity","Size", "Brand", "Type"};
            model = new DefaultTableModel(data, column);
            table.setModel(model);
            Category cat;
                for(Product p:arr){
                    if(p instanceof Cosmetics){
                        Cosmetics c=(Cosmetics) p ;
                        model.addRow(new Object[]{c.getId(),c.getName(),c.getPrice(),c.getQuantity(),c.getSize(),c.getBrand(),c.getType()});
                    }
                }
            
            
            
        }
        
        
        
        else if (box.getSelectedItem().equals("Electronic")) {
            label1.setBounds(10, 10, 100, 30);
            quantity.setBounds(100, 10, 120, 30);
            String data[][] = {};  // Initialize with actual data
            String column[] = {"Id", "Name", "Price", "Quantity","Size", "Material", "Color"};
            model = new DefaultTableModel(data, column);
            table.setModel(model);
            Category cat;
                for(Product p:arr){
                    if(p instanceof ElectronicProduct){
                        ElectronicProduct ep=(ElectronicProduct) p ;
                        model.addRow(new Object[]{ep.getId(),ep.getName(),ep.getPrice(),ep.getQuantity(),ep.getSize(),ep.getMaterial(),ep.getColor()});
                    }
                }   
        } 
        
        
        else if (box.getSelectedItem().equals("Furniture")) {
            label1.setBounds(10, 10, 100, 30);
            quantity.setBounds(100, 10, 120, 30);
            String data[][] = {};  // Initialize with actual data
            String column[] = {"Id", "Name", "Price", "Quantity","Size" ,"Material", "Dimension"};
            model = new DefaultTableModel(data, column);
            table.setModel(model);
            Category cat;
                for(Product p:arr){
                    if(p instanceof FurnitureProduct){
                        FurnitureProduct fp=(FurnitureProduct) p ;
                        model.addRow(new Object[]{fp.getId(),fp.getName(),fp.getPrice(),fp.getQuantity(),fp.getSize(),fp.getMaterial(),fp.getDimensions()});
                    }
                }
        } 
        
        
        
        else if (box.getSelectedItem().equals("Grocery")) {
            
            String data[][] = {};  // Initialize with actual data
            String column[] = {"Id", "Name", "Price", "Quantity","Size","Expiry Date", "Type"};
            model = new DefaultTableModel(data, column);
            table.setModel(model);
            Category cat;
                for(Product p:arr){
                    if(p instanceof GroceryProduct){
                        GroceryProduct gp=(GroceryProduct) p ;
                        model.addRow(new Object[]{gp.getId(),gp.getName(),gp.getPrice(),gp.getQuantity(),gp.getSize(),gp.getExpirationDate(),gp.getCategory()});
                    }
                }
            
            
            
        } 
        
        
        
        else if (box.getSelectedItem().equals("Movies")) {
            quantity.setBounds(0,0,0, 0);
            label1.setBounds(0,0,0, 0);
            String data[][] = {};  // Initialize with actual data
            String column[] = {"Id", "Name", "Price", "Format", "Director", "Duration(Minutes)"};
            model = new DefaultTableModel(data, column);
            table.setModel(model);
            Category cat;
                for(Product p:arr){
                    if(p instanceof DigitalMovie){
                        DigitalMovie dm=(DigitalMovie) p ;
                        model.addRow(new Object[]{dm.getId(),dm.getName(),dm.getPrice(),dm.getFormat(),dm.getDirector(),dm.getDuration()});
                    }
                }
            
            
            
        }
        
        
        
        else if (box.getSelectedItem().equals("Music")) {
            quantity.setBounds(0,0,0, 0);
            price.setBounds(0,0,0, 0);
            label1.setBounds(0,0,0, 0);
            label2.setBounds(0,0,0, 0);
            String data[][] = {};  // Initialize with actual data
            String column[] = {"Id", "Name", "Price", "Format", "Artist", "Duration(Minutes)"};
            model = new DefaultTableModel(data, column);
            table.setModel(model);
            for(Product p:arr){
                    if(p instanceof DigitalMusic){
                        DigitalMusic mus=(DigitalMusic) p ;
                        model.addRow(new Object[]{mus.getId(),mus.getName(),mus.getPrice(),mus.getFormat(),mus.getArtist(),mus.getDuration()});
                    }
                }
        } 
        
        
        
        else if (box.getSelectedItem().equals("Games")) {
            quantity.setBounds(0,0,0, 0);
            label1.setBounds(0,0,0, 0);
            String data[][] = {};  // Initialize with actual data
            String column[] = {"Id", "Name", "Price", "Format", "Genre"};
            model = new DefaultTableModel(data, column);
            table.setModel(model);
            for(Product p:arr){
                    if(p instanceof Games){
                        Games g=(Games) p ;
                        model.addRow(new Object[]{g.getId(),g.getName(),g.getPrice(),g.getFormat(),g.getGenre()});
                    }
                }
        }
        
        
        
        
        else if (box.getSelectedItem().equals("Ebooks")) {
            quantity.setBounds(0,0,0, 0);
            label1.setBounds(0,0,0, 0);
            String data[][] = {};  // Initialize with actual data
            String column[] = {"Id", "Name", "Price", "Format", "Author", "Pages Count"};
            model = new DefaultTableModel(data, column);
            table.setModel(model);
            for(Product p:arr){
                    if(p instanceof DigitalBook){
                        DigitalBook db=(DigitalBook) p ;
                        model.addRow(new Object[]{db.getId(),db.getName(),db.getPrice(),db.getFormat(),db.getAuthor(),db.getPageCount()});
                    }
                }
        } 
        
        
        
        
        else if (box.getSelectedItem().equals("Softwares")) {
            quantity.setBounds(0,0,0, 0);
            label1.setBounds(0,0,0, 0);
            String data[][] = {};  // Initialize with actual data
            String column[] = {"Id", "Name", "Price", "Format", "Developer", "Version"};
            model = new DefaultTableModel(data, column);
            table.setModel(model);
            for(Product p:arr){
                    if(p instanceof SoftwareProduct){
                        SoftwareProduct sp=(SoftwareProduct) p ;
                        model.addRow(new Object[]{sp.getId(),sp.getName(),sp.getPrice(),sp.getFormat(),sp.getDeveloper(),sp.getVersion()});
                    }
                }
            
            
        }
    
        
    }
    
    
    
    //Code for update button
    else if (a.getSource() == update) {
        
        int selectedRow = table.getSelectedRow();
        
                
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a row to update!");
        } 
        else if(price.getText().equals(""))
            JOptionPane.showMessageDialog(null, "Please fill the empty fields!");
        else {
            String id=(String) model.getValueAt(selectedRow,0);
            String name=(String) model.getValueAt(selectedRow,1);
//            double p=Double.parseDouble((String)model.getValueAt(selectedRow,3)) ;
                
                double pri=-1;
                
                boolean check=true;
                try{
                    pri=Double.parseDouble(price.getText());
                }
                catch(NumberFormatException ex){
                    check=false;
                    JOptionPane.showMessageDialog(null,"Price must be a double value");
                }
            String s=(String)box.getSelectedItem();
            if(s.equals("Clothing") || s.equals("Cosmetics") ||s.equals("Electronic") ||s.equals("Furniture") ||s.equals("Grocery") )
            {   
                
                int qua=-1;
                try{
                    
                    qua=Integer.parseInt(quantity.getText());
                }
                catch(NumberFormatException ex){
                    check=false;
                    JOptionPane.showMessageDialog(null,"Qunaityt must be a double value");
                }
                System.out.println(check);
                
                if(check==true){
                    for(Product pro:arr){
                    if(pro.getId().equals(id) && pro.getName().equals(name)){
                        if(pro instanceof ClothingProducts){
                            ClothingProducts cp= (ClothingProducts) pro;
                            cp.setQuantity(qua);
                            cp.setPrice(pri);
                            
                        }
                        else if(pro instanceof Cosmetics){
                            Cosmetics cp= (Cosmetics) pro;
                            cp.setQuantity(qua);
                            cp.setPrice(pri);
                        
                        }
                        else if(pro instanceof FurnitureProduct){
                            FurnitureProduct cp= (FurnitureProduct) pro;
                            cp.setQuantity(qua);
                            cp.setPrice(pri);
                        
                        }
                        else if(pro instanceof ElectronicProduct){
                            ElectronicProduct cp= (ElectronicProduct) pro;
                            cp.setQuantity(qua);
                            cp.setPrice(pri);
                        
                        }
                        else if(pro instanceof GroceryProduct){
                            GroceryProduct cp= (GroceryProduct) pro;
                            cp.setQuantity(qua);
                            cp.setPrice(pri);
                        
                        }
                        model.setValueAt(qua, selectedRow, 3);
                        model.setValueAt(pri, selectedRow, 2);
                        updateDataToFile();
                        
                    }
                        
                }
                
                
            }
                
                
                
            
            }
            else{
                    
                if(check==true){
                    for(Product pro:arr){
                    if(pro.getId().equals(id) && pro.getName().equals(name)){
                        if(pro instanceof DigitalBook){
                            DigitalBook cp= (DigitalBook) pro;
                            cp.setPrice(pri);
                        }
                        else if(pro instanceof DigitalMusic){
                            DigitalMusic cp= (DigitalMusic) pro;
                            cp.setPrice(pri);
                        
                        }
                        else if(pro instanceof DigitalMovie){
                            DigitalMovie cp= (DigitalMovie) pro;
                            cp.setPrice(pri);
                        
                        }
                        else if(pro instanceof Games){
                            Games cp= (Games) pro;
                            cp.setPrice(pri);
                        
                        }
                        else if(pro instanceof SoftwareProduct){
                            SoftwareProduct cp= (SoftwareProduct) pro;
                            cp.setPrice(pri);
                        
                        }
                        model.setValueAt(pri, selectedRow, 2);
                        updateDataToFile();
                        
                    }
                        
                }
                
                
            }
            
            }
            
            
        }
    }
    
    else if (a.getActionCommand().equalsIgnoreCase("Delete")) {
        
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a row to delete!");
        } else {
            String id=(String) model.getValueAt(selectedRow,0);
            String name=(String) model.getValueAt(selectedRow,1);
            model.removeRow(selectedRow);
            
            Iterator <Product> p=arr.iterator();//Iterator because normal way was causing error!
            while(p.hasNext()){
                Product pro = p.next();
                if(pro.getId().equals(id) && pro.getName().equals(name)){
                    p.remove();
                }
                
            }
            
            updateDataToFile();
        }
           
    }  
    else if(a.getSource()==search){
        String s=searching.getText();
        boolean found=false;
        for(int i=0;i<model.getRowCount();i++){
            for(int j=0;j<2;j++){
                if(model.getValueAt(i,j).equals(s)){
                    String sample= "Product Found\n1.Name: "+model.getValueAt(i,0)+"\n2.Id: "+model.getValueAt(i,1)+"\n3.Price"+model.getValueAt(i,2);
                    JOptionPane.showMessageDialog(null,sample);
                    found=true;
                    break;
                }
                
                    
            }
        }
        if(found==false)
            JOptionPane.showMessageDialog(null,"Cannot find product!");
        
    }
    else if(a.getSource()==clear){
        price.setText("");
        update.setText("");
    }    
    
    else if(a.getSource()==save)
        updateDataToFile();
    else if(a.getSource()==back){
        f.dispose();
        new DashBoard();
    }    
   
        
    
   
}

   
    
    private void print(){
        for(Product p:arr){
            System.out.println(p);
        }
    }
    
    
   
 
    
    
    
    
    
}
