/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.GUI.PhysicalProducts;
import com.mycompany.inventorymanagementsystem.PhysicalProduct;
import java.io.Serializable;
/**
 *
 * @author malik
 */
public class ClothingProducts extends PhysicalProduct implements Serializable {
    
    private static final long serialVersionUID = 4661633562961544696L;
    private String material;
    private String color;
    
     public ClothingProducts(){
     
     }
    
    public ClothingProducts(String productId, String productName, double price, int quantityInStock,String size, String material, String color) {
        super(productId, productName, price, quantityInStock,size);
        this.material = material;
        this.color = color;
    }
    
    


    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

}
