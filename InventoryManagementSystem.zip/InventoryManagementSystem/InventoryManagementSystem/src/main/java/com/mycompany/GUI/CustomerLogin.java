
package com.mycompany.GUI;

import com.mycompany.inventorymanagementsystem.Admin;
import com.mycompany.inventorymanagementsystem.Customer;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.io.*;
import com.mycompany.inventorymanagementsystem.Inventory;
import java.util.ArrayList;
import static javax.swing.WindowConstants.DISPOSE_ON_CLOSE;


public class CustomerLogin extends JFrame implements ActionListener{
    ArrayList<Customer> customers= new ArrayList<>();
    
    JFrame f= new JFrame("Customer Login");
    ImageIcon admin;
    JButton login,back,signUp;
    JTextField userName;
    JPasswordField pass;
    public CustomerLogin(){
        
        getCustomerCredentials();
        print();
        f.setSize(1000, 600);
        f.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        f.getContentPane().setBackground(Color.decode("#03445A"));
        f.setResizable(false);
        f.setLocationRelativeTo(null);
        
        
        JPanel leftPanel = new JPanel();
        leftPanel.setLayout(new BorderLayout());
        leftPanel.setBackground(Color.decode("#03445A"));
        
        admin = new ImageIcon("src\\images\\admin.png");
        JLabel imageLabel = new JLabel(admin);
        leftPanel.add(imageLabel, BorderLayout.CENTER);
        
        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(null);
        rightPanel.setBackground(Color.decode("#03445A"));
        
        
        
        JLabel heading= new JLabel("Welcome to Login");
        heading.setBounds(130, 130, 120, 30);
        heading.setForeground(Color.white);
        
        //For UserName;
        JLabel l1 = new JLabel("UserName/Email: ");
        l1.setBounds(50, 200, 100, 30);
        l1.setForeground(Color.white);
        
        userName= new JTextField();
        userName.setBounds(155, 205, 180, 20);
        
        //For Password
        JLabel l2 = new JLabel("           Password: ");
        l2.setBounds(50, 250, 100, 30);
        l2.setForeground(Color.white);
        
        pass= new JPasswordField();
        pass.setBounds(155, 255, 180, 20);
        
        login= new JButton("Login");
        login.setBounds(130, 320, 120, 30);
        login.addActionListener(this);
        
        signUp= new JButton("Signup");
        signUp.setBounds(130, 450, 120, 30);
        signUp.addActionListener(this);
        
        back= new JButton("Back");
        back.setBounds(130, 400, 120, 30);
        back.addActionListener(this);
        
        rightPanel.add(heading);
        rightPanel.add(l1);
        rightPanel.add(userName);
        rightPanel.add(l2);
        rightPanel.add(pass);
        rightPanel.add(login);
        rightPanel.add(signUp);
        rightPanel.add(back);
        
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(Color.WHITE);

        JLabel developedByLabel = new JLabel("Developed by Abdullah Khan(FA22-BSE-028), Hizqeel Mirza(SP22-BSE-019), Rizwan Akhtar(FA23-BSE-121)");
        developedByLabel.setForeground(Color.black);
        bottomPanel.add(developedByLabel);
        
        f.setLayout(new BorderLayout());
        f.add(leftPanel, BorderLayout.WEST);
        f.add(rightPanel, BorderLayout.CENTER);
        f.add(bottomPanel, BorderLayout.SOUTH);
        f.setVisible(true);
        
    }
    
    public void getCustomerCredentials() {
        try{
        ObjectInputStream input= new ObjectInputStream(new FileInputStream("customer.ser"));
            customers=(ArrayList<Customer>)input.readObject();
            input.close();
        }
        catch(EOFException a){
            System.out.println("End reached!");
        }
        catch(FileNotFoundException a){
            a.printStackTrace();
        }
        catch(IOException a){
            a.printStackTrace();
        }
        catch(ClassNotFoundException a){
            a.printStackTrace();
        }
        
        
    }
   @Override
    public void actionPerformed(ActionEvent e) {
    

    if (e.getSource() == login) {
        String name=userName.getText();
        String password=new String(pass.getPassword());
        for (Customer a : customers) {
            if (name.equals(a.getUserName()) && password.equals(a.getPassword())){
                f.dispose();
                new CustomerDashboard();
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Invalid Password or username");
    }
    else if(e.getSource()==back){
        f.dispose();
        new Welcome();
    }
    else if(e.getSource()==signUp)
        {
            f.dispose();
            new signUp();
        }
}   
    
    private void print(){
        for(Customer c: customers){
            System.out.println(c.getUserName());
            System.out.println(c.getPassword());
        }
    }

    
}
